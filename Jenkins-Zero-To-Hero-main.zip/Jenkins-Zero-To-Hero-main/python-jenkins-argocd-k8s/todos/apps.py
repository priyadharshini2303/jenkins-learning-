from django.apps import AppConfig


class TodosConfig(AppConfig):
    name = 'todos'
